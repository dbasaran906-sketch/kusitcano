# KUŞİTCANO

Hedef saniyeyi en iyi yakalayan kazanır.

## Kurulum
1. GitHub'da yeni repo aç, bu dosyaları yükle: `main.dart`, `pubspec.yaml`, `icon.png`, `README.md`.
2. `.github/workflows/build.yml` dosyasını da ekle (Add file > Create new file, ismine `.github/workflows/build.yml` yaz, içeriği yapıştır).
3. Yükleyince Actions kendiliğinden APK'yı derler (yaklaşık 5-8 dk).
4. Repo ana sayfasında sağdaki **Releases** bölümünden `app-release.apk` dosyasını telefona indir ve yükle.
