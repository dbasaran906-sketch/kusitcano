import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ───────────────────────── Temalar ─────────────────────────

class KTheme {
  final String name;
  final Color primary;
  final Color secondary;
  const KTheme(this.name, this.primary, this.secondary);
}

const List<KTheme> themes = [
  KTheme('Altın Sarısı', Color(0xFFD4AF37), Color(0xFFFFD600)),
  KTheme('Neon Camgöbeği', Color(0xFF00F5FF), Color(0xFF0091FF)),
  KTheme('Neon Pembe', Color(0xFFFF2BD6), Color(0xFFFF6EC7)),
  KTheme('Neon Yeşil', Color(0xFF39FF14), Color(0xFFB6FF00)),
  KTheme('Neon Mor', Color(0xFFB026FF), Color(0xFF6C63FF)),
  KTheme('Neon Turuncu', Color(0xFFFF6A00), Color(0xFFFF2D55)),
];

// ───────────────────────── Ayarlar ─────────────────────────

class AppSettings extends ChangeNotifier {
  int themeIndex = 0;
  bool showCounter = true;

  KTheme get theme => themes[themeIndex];

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      themeIndex = (p.getInt('theme') ?? 0).clamp(0, themes.length - 1).toInt();
      showCounter = p.getBool('show') ?? true;
    } catch (_) {}
    notifyListeners();
  }

  Future<void> setTheme(int i) async {
    themeIndex = i;
    notifyListeners();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('theme', i);
    } catch (_) {}
  }

  Future<void> setShowCounter(bool v) async {
    showCounter = v;
    notifyListeners();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('show', v);
    } catch (_) {}
  }
}

final AppSettings settings = AppSettings();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await settings.load();
  runApp(const KusitcanoApp());
}

class KusitcanoApp extends StatelessWidget {
  const KusitcanoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) {
        final t = settings.theme;
        return MaterialApp(
          title: 'KUŞİTCANO',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            brightness: Brightness.dark,
            useMaterial3: true,
            scaffoldBackgroundColor: Colors.black,
            colorScheme: ColorScheme.dark(
              primary: t.primary,
              secondary: t.secondary,
              surface: const Color(0xFF0B0B0B),
            ),
          ),
          home: const SplashScreen(),
        );
      },
    );
  }
}

// ───────────────────────── Ortak parçalar ─────────────────────────

BoxDecoration glowBox(Color c,
    {double radius = 20, bool filled = false, double width = 2}) {
  return BoxDecoration(
    color: filled ? c.withOpacity(0.12) : Colors.black,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: c, width: width),
    boxShadow: [
      BoxShadow(color: c.withOpacity(0.5), blurRadius: 18, spreadRadius: 1),
    ],
  );
}

class NeonButton extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  final double height;
  final double fontSize;
  final Color? color;

  const NeonButton({
    super.key,
    required this.text,
    required this.onTap,
    this.height = 56,
    this.fontSize = 18,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.primary;
    return GestureDetector(
      onTap: onTap,
      child: Opacity(
        opacity: onTap == null ? 0.4 : 1,
        child: Container(
          height: height,
          width: double.infinity,
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: glowBox(c, filled: true),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: c,
              fontSize: fontSize,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
            ),
          ),
        ),
      ),
    );
  }
}

TextStyle glowText(Color c, double size, {FontWeight w = FontWeight.w800}) {
  return TextStyle(
    color: c,
    fontSize: size,
    fontWeight: w,
    letterSpacing: 1.2,
    shadows: [Shadow(color: c.withOpacity(0.7), blurRadius: 14)],
    fontFeatures: const [FontFeature.tabularFigures()],
  );
}

// ───────────────────────── Açılış ekranı ─────────────────────────

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(milliseconds: 1800), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Image.asset('icon.png', width: w * 0.85),
      ),
    );
  }
}

// ───────────────────────── Ana ekran (kurulum) ─────────────────────────

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<TextEditingController> _ctrls = [
    TextEditingController(),
    TextEditingController(),
  ];
  int _rounds = 3;

  @override
  void dispose() {
    for (final c in _ctrls) {
      c.dispose();
    }
    super.dispose();
  }

  void _start() {
    final names = <String>[];
    for (var i = 0; i < _ctrls.length; i++) {
      final n = _ctrls[i].text.trim();
      names.add(n.isEmpty ? 'Oyuncu ${i + 1}' : n);
    }
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => GameScreen(players: names, rounds: _rounds),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                icon: Icon(Icons.settings, color: cs.primary, size: 28),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SettingsScreen()),
                ),
              ),
            ),
            Center(child: Image.asset('icon.png', height: 130)),
            const SizedBox(height: 8),
            Center(child: Text('KUŞİTCANO', style: glowText(cs.primary, 34))),
            const SizedBox(height: 4),
            const Center(
              child: Text(
                'Hedef saniyeyi en iyi yakalayan kazanır',
                style: TextStyle(color: Colors.white60),
              ),
            ),
            const SizedBox(height: 24),
            Text('OYUNCULAR', style: glowText(cs.secondary, 14)),
            const SizedBox(height: 8),
            for (var i = 0; i < _ctrls.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: TextField(
                  key: ObjectKey(_ctrls[i]),
                  controller: _ctrls[i],
                  textCapitalization: TextCapitalization.words,
                  style: const TextStyle(fontSize: 18),
                  decoration: InputDecoration(
                    labelText: 'Oyuncu ${i + 1}',
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide(color: cs.primary.withOpacity(0.6)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide(color: cs.primary, width: 2),
                    ),
                    suffixIcon: _ctrls.length > 2
                        ? IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: () {
                              final removed = _ctrls[i];
                              setState(() => _ctrls.removeAt(i));
                              WidgetsBinding.instance.addPostFrameCallback(
                                (_) => removed.dispose(),
                              );
                            },
                          )
                        : null,
                  ),
                ),
              ),
            if (_ctrls.length < 8)
              TextButton.icon(
                onPressed: () =>
                    setState(() => _ctrls.add(TextEditingController())),
                icon: Icon(Icons.add, color: cs.primary),
                label: Text('Oyuncu ekle', style: TextStyle(color: cs.primary)),
              ),
            const SizedBox(height: 16),
            Text('TUR SAYISI', style: glowText(cs.secondary, 14)),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  iconSize: 36,
                  color: cs.primary,
                  icon: const Icon(Icons.remove_circle_outline),
                  onPressed:
                      _rounds > 1 ? () => setState(() => _rounds--) : null,
                ),
                SizedBox(
                  width: 80,
                  child: Text(
                    '$_rounds',
                    textAlign: TextAlign.center,
                    style: glowText(cs.primary, 40),
                  ),
                ),
                IconButton(
                  iconSize: 36,
                  color: cs.primary,
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed:
                      _rounds < 20 ? () => setState(() => _rounds++) : null,
                ),
              ],
            ),
            const SizedBox(height: 24),
            NeonButton(text: 'OYUNA BAŞLA', onTap: _start, height: 64, fontSize: 22),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────── Ayarlar ekranı ─────────────────────────

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) {
        final cs = Theme.of(context).colorScheme;
        return Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.black,
            title: Text('AYARLAR', style: glowText(cs.primary, 20)),
            iconTheme: IconThemeData(color: cs.primary),
          ),
          body: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: glowBox(cs.primary, radius: 16),
                child: SwitchListTile(
                  value: settings.showCounter,
                  onChanged: settings.setShowCounter,
                  activeColor: cs.primary,
                  title: const Text('Sayacı göster',
                      style: TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(
                    settings.showCounter
                        ? 'Açık: süre ekranda akar'
                        : 'Kapalı: süre gizli, saniyeyi içinden say!',
                  ),
                ),
              ),
              const SizedBox(height: 28),
              Text('TEMA', style: glowText(cs.secondary, 14)),
              const SizedBox(height: 12),
              for (var i = 0; i < themes.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: GestureDetector(
                    onTap: () => settings.setTheme(i),
                    child: Container(
                      height: 56,
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      decoration: glowBox(
                        themes[i].primary,
                        radius: 16,
                        filled: settings.themeIndex == i,
                        width: settings.themeIndex == i ? 3 : 1.5,
                      ),
                      child: Row(
                        children: [
                          Text(
                            themes[i].name,
                            style: glowText(themes[i].primary, 18),
                          ),
                          const Spacer(),
                          if (settings.themeIndex == i)
                            Icon(Icons.check_circle, color: themes[i].primary),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

// ───────────────────────── Oyun ekranı ─────────────────────────

enum Phase { askTarget, play, roundResult, finalResult }

class Standing {
  final int index;
  int wins = 0;
  double total = 0;
  Standing(this.index);
}

class GameScreen extends StatefulWidget {
  final List<String> players;
  final int rounds;
  const GameScreen({super.key, required this.players, required this.rounds});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  Phase _phase = Phase.askTarget;
  int _round = 0;
  int _playerIdx = 0;

  final List<double> _targets = [];
  final List<List<double>> _times = []; // _times[tur][oyuncu] saniye
  final TextEditingController _targetCtrl = TextEditingController(text: '4');
  final Stopwatch _sw = Stopwatch();
  Timer? _ticker;
  bool _running = false;
  bool _stopped = false;
  double _lastTime = 0;
  String? _error;

  int get _n => widget.players.length;

  @override
  void dispose() {
    _ticker?.cancel();
    _targetCtrl.dispose();
    super.dispose();
  }

  // ── Hedef girişi ──
  void _confirmTarget() {
    final t = double.tryParse(_targetCtrl.text.trim().replaceAll(',', '.'));
    if (t == null || t <= 0 || t > 600) {
      setState(() => _error = '0\'dan büyük bir sayı gir (örn. 4 veya 7.5)');
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      _error = null;
      _targets.add(t);
      _times.add(List<double>.filled(_n, 0));
      _playerIdx = 0;
      _running = false;
      _stopped = false;
      _lastTime = 0;
      _sw.reset();
      _phase = Phase.play;
    });
  }

  // ── Kronometre ──
  void _onBigTap() {
    if (_stopped) return;
    if (!_running) {
      _sw.reset();
      _sw.start();
      _ticker = Timer.periodic(const Duration(milliseconds: 30), (_) {
        if (mounted) setState(() {});
      });
      HapticFeedback.lightImpact();
      setState(() => _running = true);
    } else {
      _sw.stop();
      _ticker?.cancel();
      final t = _sw.elapsedMicroseconds / 1000000.0;
      HapticFeedback.mediumImpact();
      setState(() {
        _lastTime = t;
        _times[_round][_playerIdx] = t;
        _running = false;
        _stopped = true;
      });
    }
  }

  void _nextPlayer() {
    setState(() {
      if (_playerIdx < _n - 1) {
        _playerIdx++;
        _stopped = false;
        _lastTime = 0;
        _sw.reset();
      } else {
        _phase = Phase.roundResult;
      }
    });
  }

  void _nextRound() {
    setState(() {
      if (_round < widget.rounds - 1) {
        _round++;
        _error = null;
        _phase = Phase.askTarget;
      } else {
        _phase = Phase.finalResult;
      }
    });
  }

  // ── Hesaplar ──
  double _diff(int r, int p) => (_times[r][p] - _targets[r]).abs();

  List<int> _roundWinners(int r) {
    var best = double.infinity;
    for (var p = 0; p < _n; p++) {
      if (_diff(r, p) < best) best = _diff(r, p);
    }
    return [
      for (var p = 0; p < _n; p++)
        if ((_diff(r, p) - best).abs() < 1e-9) p
    ];
  }

  List<Standing> _standings() {
    final list = [for (var p = 0; p < _n; p++) Standing(p)];
    for (var r = 0; r < _times.length; r++) {
      for (final w in _roundWinners(r)) {
        list[w].wins++;
      }
      for (var p = 0; p < _n; p++) {
        list[p].total += _diff(r, p);
      }
    }
    list.sort((a, b) {
      if (a.wins != b.wins) return b.wins.compareTo(a.wins);
      return a.total.compareTo(b.total);
    });
    return list;
  }

  String _signed(double v) => (v >= 0 ? '+' : '') + v.toStringAsFixed(3);

  Future<bool> _confirmExit() async {
    final res = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF111111),
        title: const Text('Oyundan çıkılsın mı?'),
        content: const Text('Şu anki oyun kaybolacak.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Devam et')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Çık')),
        ],
      ),
    );
    return res == true;
  }

  // ───────────── Arayüz ─────────────

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _phase == Phase.finalResult,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final ok = await _confirmExit();
        if (ok && mounted) Navigator.of(context).pop();
      },
      child: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: switch (_phase) {
              Phase.askTarget => _buildAsk(),
              Phase.play => _buildPlay(),
              Phase.roundResult => _buildRoundResult(),
              Phase.finalResult => _buildFinal(),
            },
          ),
        ),
      ),
    );
  }

  Widget _buildAsk() {
    final cs = Theme.of(context).colorScheme;
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('TUR ${_round + 1} / ${widget.rounds}',
                style: glowText(cs.secondary, 18)),
            const SizedBox(height: 24),
            Text('Hedef kaç saniye?', style: glowText(cs.primary, 28)),
            const SizedBox(height: 24),
            SizedBox(
              width: 200,
              child: TextField(
                controller: _targetCtrl,
                textAlign: TextAlign.center,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                style: glowText(cs.primary, 48),
                decoration: InputDecoration(
                  suffixText: 'sn',
                  errorText: _error,
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide(color: cs.primary, width: 2),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide(color: cs.secondary, width: 3),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text('Herkes bu turda aynı hedefe oynar',
                style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 28),
            NeonButton(text: 'TAMAM', onTap: _confirmTarget, height: 60),
          ],
        ),
      ),
    );
  }

  Widget _buildPlay() {
    final cs = Theme.of(context).colorScheme;
    final name = widget.players[_playerIdx];
    final target = _targets[_round];
    final show = settings.showCounter;
    final elapsed = _running ? _sw.elapsedMicroseconds / 1000000.0 : _lastTime;

    String shown;
    if (show) {
      shown = elapsed.toStringAsFixed(2);
    } else if (_running) {
      shown = '• • •';
    } else if (_stopped) {
      shown = '✔';
    } else {
      shown = '?.??';
    }

    final bigLabel = _stopped ? 'KAYDEDİLDİ' : (_running ? 'DURDUR' : 'BAŞLAT');
    final bigColor = _stopped
        ? Colors.white38
        : (_running ? cs.secondary : cs.primary);
    final isLast = _playerIdx == _n - 1;

    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('TUR ${_round + 1} / ${widget.rounds}',
                style: glowText(cs.secondary, 16)),
            const SizedBox(height: 6),
            Text('HEDEF: ${_fmtTarget(target)} SN',
                style: glowText(cs.primary, 30)),
            const SizedBox(height: 18),
            Text('Sıra:', style: const TextStyle(color: Colors.white60)),
            Text(name,
                textAlign: TextAlign.center,
                style: glowText(Colors.white, 34)),
            const SizedBox(height: 22),
            Text(shown, style: glowText(cs.primary, 64)),
            const SizedBox(height: 22),
            GestureDetector(
              onTapDown: (_) => _onBigTap(),
              child: Container(
                width: 210,
                height: 210,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: bigColor.withOpacity(0.12),
                  border: Border.all(color: bigColor, width: 4),
                  boxShadow: [
                    BoxShadow(
                        color: bigColor.withOpacity(0.55),
                        blurRadius: 26,
                        spreadRadius: 2),
                  ],
                ),
                child: Text(bigLabel, style: glowText(bigColor, 26)),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              height: 60,
              child: _stopped
                  ? NeonButton(
                      text: isLast
                          ? 'TUR SONUCUNU GÖR'
                          : 'SIRADAKİ: ${widget.players[_playerIdx + 1]}',
                      onTap: _nextPlayer,
                      height: 60,
                    )
                  : null,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoundResult() {
    final cs = Theme.of(context).colorScheme;
    final r = _round;
    final order = List<int>.generate(_n, (i) => i)
      ..sort((a, b) => _diff(r, a).compareTo(_diff(r, b)));
    final winners = _roundWinners(r);
    final winnerNames = winners.map((i) => widget.players[i]).join(' & ');
    final last = r == widget.rounds - 1;

    return Column(
      children: [
        Text('TUR ${r + 1} SONUCU', style: glowText(cs.secondary, 18)),
        const SizedBox(height: 4),
        Text('Hedef: ${_fmtTarget(_targets[r])} sn',
            style: glowText(cs.primary, 24)),
        const SizedBox(height: 12),
        Text('🏆 $winnerNames',
            textAlign: TextAlign.center, style: glowText(Colors.white, 24)),
        const SizedBox(height: 16),
        Expanded(
          child: ListView(
            children: [
              for (var k = 0; k < order.length; k++)
                _resultTile(
                  rank: k + 1,
                  name: widget.players[order[k]],
                  line1: '${_times[r][order[k]].toStringAsFixed(3)} sn',
                  line2: _signed(_times[r][order[k]] - _targets[r]),
                  highlight: winners.contains(order[k]),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        NeonButton(
          text: last ? 'FİNAL SONUCU' : 'SONRAKİ TUR',
          onTap: _nextRound,
          height: 60,
        ),
      ],
    );
  }

  Widget _buildFinal() {
    final cs = Theme.of(context).colorScheme;
    final st = _standings();
    const medals = ['🥇', '🥈', '🥉'];

    return Column(
      children: [
        Text('FİNAL', style: glowText(cs.secondary, 18)),
        const SizedBox(height: 4),
        Text('🏆 ${widget.players[st.first.index]} KAZANDI!',
            textAlign: TextAlign.center, style: glowText(cs.primary, 28)),
        const SizedBox(height: 6),
        const Text(
          'Sıralama: kazanılan tur sayısı.\nEşitlikte hedefe toplam fark az olan öne geçer.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white54, fontSize: 12),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: ListView(
            children: [
              for (var k = 0; k < st.length; k++)
                _resultTile(
                  rank: k + 1,
                  medal: k < 3 ? medals[k] : null,
                  name: widget.players[st[k].index],
                  line1: '${st[k].wins} tur kazandı',
                  line2: 'toplam fark ${st[k].total.toStringAsFixed(3)} sn',
                  highlight: k == 0,
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        NeonButton(
          text: 'YENİ OYUN',
          onTap: () => Navigator.of(context).pop(),
          height: 60,
        ),
      ],
    );
  }

  Widget _resultTile({
    required int rank,
    required String name,
    required String line1,
    required String line2,
    bool highlight = false,
    String? medal,
  }) {
    final cs = Theme.of(context).colorScheme;
    final c = highlight ? cs.primary : Colors.white38;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: glowBox(c, radius: 16, filled: highlight, width: highlight ? 2.5 : 1.2),
      child: Row(
        children: [
          SizedBox(
            width: 44,
            child: Text(medal ?? '$rank.',
                style: TextStyle(
                    fontSize: medal != null ? 28 : 22,
                    fontWeight: FontWeight.w800,
                    color: c)),
          ),
          Expanded(
            child: Text(name,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 20, fontWeight: FontWeight.w700)),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(line1,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: c,
                      fontFeatures: const [FontFeature.tabularFigures()])),
              Text(line2,
                  style: const TextStyle(color: Colors.white60, fontSize: 13)),
            ],
          ),
        ],
      ),
    );
  }

  String _fmtTarget(double t) =>
      t == t.roundToDouble() ? t.toInt().toString() : t.toString();
}
